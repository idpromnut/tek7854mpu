7-Feb-04

The two text files in this archive serve different, yet related, purposes.

tek7854.txt -- Describes the contents and use of the ROM image files contained herein.

hp3456.txt -- Describes how to replace the older Motorola ROMs that may be found in the 7854 with more modern (or at least available) devices, such as the 2732. It also contains helpful information on repairing another golden oldie, the HP3456 multimeter.

Thanks are due to Dave DiGiacomo for providing the original version of this archive on his site.

(Bruce Lane, kyrrin@bluefeathertech.com)
